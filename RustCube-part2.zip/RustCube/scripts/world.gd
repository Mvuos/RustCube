class_name VoxelWorld
extends Node3D
# Кубический мир: 3 биома (лес / зима / лето), деревья, руды, меши чанков.

signal gen_progress(value: float, text: String)

var blocks := PackedByteArray()
var heights := PackedInt32Array()   # высота земли в колонке
var colmax := PackedInt32Array()    # самая высокая занятая клетка (с деревьями)
var biomes := PackedByteArray()     # 0 лес, 1 зима, 2 лето
var chunk_nodes := {}
var objects := {}                   # id -> {left, per_hit, blocks}
var obj_at := {}                    # Vector3i -> id (то, что можно бить)
var next_obj := 1
var rng := RandomNumberGenerator.new()
var winter_c := Vector2.ZERO
var summer_c := Vector2.ZERO
var noise_h := FastNoiseLite.new()
var noise_b := FastNoiseLite.new()
var noise_b2 := FastNoiseLite.new()
var mat: StandardMaterial3D
var world_seed := 0
var minimap: ImageTexture

var FN := [Vector3i(1, 0, 0), Vector3i(-1, 0, 0), Vector3i(0, 1, 0), Vector3i(0, -1, 0), Vector3i(0, 0, 1), Vector3i(0, 0, -1)]
var FU := [Vector3i(0, 1, 0), Vector3i(0, 0, 1), Vector3i(0, 0, 1), Vector3i(1, 0, 0), Vector3i(1, 0, 0), Vector3i(0, 1, 0)]
var FV := [Vector3i(0, 0, 1), Vector3i(0, 1, 0), Vector3i(1, 0, 0), Vector3i(0, 0, 1), Vector3i(0, 1, 0), Vector3i(1, 0, 0)]


func idx(x: int, y: int, z: int) -> int:
	return (y * Cfg.WZ + z) * Cfg.WX + x


func get_block(x: int, y: int, z: int) -> int:
	if x < 0 or z < 0 or x >= Cfg.WX or z >= Cfg.WZ or y < 0 or y >= Cfg.WY:
		return 0
	return blocks[idx(x, y, z)]


func _solid(x: int, y: int, z: int) -> bool:
	if y < 0:
		return true
	if x < 0 or z < 0 or x >= Cfg.WX or z >= Cfg.WZ or y >= Cfg.WY:
		return false
	return blocks[(y * Cfg.WZ + z) * Cfg.WX + x] != 0


func surface_top(x: int, z: int) -> float:
	# верхняя грань земли (координата Y) в колонке x,z
	x = clampi(x, 0, Cfg.WX - 1)
	z = clampi(z, 0, Cfg.WZ - 1)
	return float(heights[z * Cfg.WX + x] + 1)


func biome_at(x: int, z: int) -> int:
	x = clampi(x, 0, Cfg.WX - 1)
	z = clampi(z, 0, Cfg.WZ - 1)
	return biomes[z * Cfg.WX + x]


func biome_name(x: int, z: int) -> String:
	match biome_at(x, z):
		1: return "Зима"
		2: return "Лето"
	return "Лес"


func _biome_calc(x: int, z: int) -> int:
	var p := Vector2(x, z)
	var n1 := noise_b.get_noise_2d(x, z)
	var n2 := noise_b2.get_noise_2d(x, z)
	if p.distance_to(winter_c) / Cfg.WINTER_R + n1 * 0.5 < 1.0:
		return 1
	if p.distance_to(summer_c) / Cfg.SUMMER_R + n2 * 0.5 < 1.0:
		return 2
	return 0


func _pick_centers() -> void:
	var mw := Cfg.WINTER_R + 10.0
	var ms := Cfg.SUMMER_R + 10.0
	for i in 80:
		winter_c = Vector2(rng.randf_range(mw, Cfg.WX - mw), rng.randf_range(mw, Cfg.WZ - mw))
		summer_c = Vector2(rng.randf_range(ms, Cfg.WX - ms), rng.randf_range(ms, Cfg.WZ - ms))
		if winter_c.distance_to(summer_c) > Cfg.WINTER_R + Cfg.SUMMER_R + 18.0:
			return


func generate(seed_val: int) -> void:
	world_seed = seed_val
	rng.seed = seed_val
	noise_h.seed = seed_val
	noise_h.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise_h.frequency = 0.022
	noise_h.fractal_octaves = 3
	noise_b.seed = seed_val + 11
	noise_b.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise_b.frequency = 0.035
	noise_b2.seed = seed_val + 29
	noise_b2.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise_b2.frequency = 0.04
	mat = StandardMaterial3D.new()
	mat.vertex_color_use_as_albedo = true
	mat.roughness = 1.0

	# море вокруг острова
	var wm := MeshInstance3D.new()
	var pm := PlaneMesh.new()
	pm.size = Vector2(Cfg.WX * 6.0, Cfg.WZ * 6.0)
	wm.mesh = pm
	var wmat := StandardMaterial3D.new()
	wmat.albedo_color = Color(0.16, 0.44, 0.72, 0.85)
	wmat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	wmat.roughness = 0.3
	wm.material_override = wmat
	wm.position = Vector3(Cfg.WX / 2.0, Cfg.SEA_Y, Cfg.WZ / 2.0)
	add_child(wm)

	blocks.resize(Cfg.WX * Cfg.WY * Cfg.WZ)
	blocks.fill(0)
	heights.resize(Cfg.WX * Cfg.WZ)
	colmax.resize(Cfg.WX * Cfg.WZ)
	biomes.resize(Cfg.WX * Cfg.WZ)
	_pick_centers()

	var step := Cfg.WX * Cfg.WZ
	for z in Cfg.WZ:
		for x in Cfg.WX:
			var ci := z * Cfg.WX + x
			var b := _biome_calc(x, z)
			biomes[ci] = b
			var ed := mini(mini(x, z), mini(Cfg.WX - 1 - x, Cfg.WZ - 1 - z))
			var fo := 0.0
			if ed < 55:
				fo = pow(1.0 - ed / 55.0, 2.0) * 20.0
			var h := int(round(Cfg.BASE_H + noise_h.get_noise_2d(x, z) * 8.0 - fo))
			h = clampi(h, 2, 30)
			heights[ci] = h
			colmax[ci] = h
			var top := Cfg.GRASS
			if b == 1:
				top = Cfg.SNOW
			elif b == 2:
				top = Cfg.SAND
			if h <= Cfg.BEACH_H:
				top = Cfg.SAND
			for y in range(0, h + 1):
				var id := Cfg.STONE
				if y == h:
					id = top
				elif y >= h - 3:
					id = Cfg.SAND if b == 2 else Cfg.DIRT
				blocks[ci + y * step] = id
		if z % 8 == 0:
			gen_progress.emit(0.30 * float(z) / Cfg.WZ, "Рельеф и биомы...")
			await get_tree().process_frame

	gen_progress.emit(0.32, "Деревья...")
	await get_tree().process_frame
	_gen_trees()
	gen_progress.emit(0.40, "Руда...")
	await get_tree().process_frame
	_gen_nodes()
	_make_minimap()

	var nc := Cfg.WX / Cfg.CHUNK
	var total := nc * (Cfg.WZ / Cfg.CHUNK)
	var done := 0
	for cz in range(Cfg.WZ / Cfg.CHUNK):
		for cx in range(nc):
			build_chunk(cx, cz)
			done += 1
			if done % 3 == 0:
				gen_progress.emit(0.42 + 0.58 * float(done) / total, "Строю мир...")
				await get_tree().process_frame
	gen_progress.emit(1.0, "Готово")


# ---------- деревья ----------

func _put(list: Array, x: int, y: int, z: int, id: int) -> void:
	if x < 0 or z < 0 or x >= Cfg.WX or z >= Cfg.WZ or y < 0 or y >= Cfg.WY:
		return
	var i := idx(x, y, z)
	if blocks[i] != 0:
		return
	blocks[i] = id
	list.append(Vector3i(x, y, z))
	var ci := z * Cfg.WX + x
	if y > colmax[ci]:
		colmax[ci] = y


func _tree_area_free(x: int, h: int, z: int) -> bool:
	for dz in range(-2, 3):
		for dx in range(-2, 3):
			if get_block(x + dx, h + 2, z + dz) != 0:
				return false
			if get_block(x + dx, h + 1, z + dz) != 0:
				return false
	return true


func _gen_trees() -> void:
	for z in range(4, Cfg.WZ - 4):
		for x in range(4, Cfg.WX - 4):
			var ci := z * Cfg.WX + x
			var b := biomes[ci]
			var chance := 0.016
			if b == 1:
				chance = 0.014
			elif b == 2:
				chance = 0.008
			if rng.randf() > chance:
				continue
			var h := heights[ci]
			if h <= Cfg.BEACH_H:
				continue
			if not _tree_area_free(x, h, z):
				continue
			var kind := ""
			if b == 0:
				kind = "birch" if rng.randf() < 0.5 else "oak"
			elif b == 1:
				kind = "spruce"
			else:
				kind = "palm"
			_make_tree(kind, x, h, z)


func _make_tree(kind: String, x: int, h: int, z: int) -> void:
	var all := []
	var logs := []
	var log_id := Cfg.LOG_BIRCH
	var th := 5
	match kind:
		"birch":
			log_id = Cfg.LOG_BIRCH
			th = 5 + rng.randi_range(0, 1)
		"oak":
			log_id = Cfg.LOG_OAK
			th = 4 + rng.randi_range(0, 1)
		"palm":
			log_id = Cfg.LOG_PALM
			th = 6 + rng.randi_range(0, 1)
		"spruce":
			log_id = Cfg.LOG_SPRUCE
			th = 6 + rng.randi_range(0, 1)
	for dy in range(1, th + 1):
		_put(logs, x, h + dy, z, log_id)
	all.append_array(logs)
	var yt := h + th
	var leaves := []
	match kind:
		"birch":
			for ly in range(yt - 2, yt + 2):
				var r := 2 if ly < yt else 1
				for dz in range(-r, r + 1):
					for dx in range(-r, r + 1):
						if r == 2 and absi(dx) == 2 and absi(dz) == 2:
							continue
						_put(leaves, x + dx, ly, z + dz, Cfg.LEAF_BIRCH)
		"oak":
			var rs := [2, 3, 3, 2, 1]
			for k in 5:
				var ly := yt - 2 + k
				var r: int = rs[k]
				for dz in range(-r, r + 1):
					for dx in range(-r, r + 1):
						if dx * dx + dz * dz > r * r + 1:
							continue
						_put(leaves, x + dx, ly, z + dz, Cfg.LEAF_OAK)
		"palm":
			_put(leaves, x, yt + 1, z, Cfg.LEAF_PALM)
			_put(leaves, x, yt + 2, z, Cfg.LEAF_PALM)
			var dirs := [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]
			for d in dirs:
				for i in range(1, 4):
					var ly := yt + 1 if i < 3 else yt
					_put(leaves, x + d.x * i, ly, z + d.y * i, Cfg.LEAF_PALM)
			for dx in [-1, 1]:
				for dz in [-1, 1]:
					_put(leaves, x + dx, yt + 1, z + dz, Cfg.LEAF_PALM)
					_put(leaves, x + dx * 2, yt, z + dz * 2, Cfg.LEAF_PALM)
		"spruce":
			for ly in range(h + 3, yt + 3):
				var t := yt + 2 - ly
				var r := clampi(int(ceil(t / 2.0)), 0, 3)
				for dz in range(-r, r + 1):
					for dx in range(-r, r + 1):
						if r >= 2 and dx * dx + dz * dz > r * r + 1:
							continue
						_put(leaves, x + dx, ly, z + dz, Cfg.LEAF_SPRUCE)
	all.append_array(leaves)
	var total: int = Cfg.TREE_WOOD[log_id]
	var oid := _new_object({"wood": total}, all)
	for p in logs:
		obj_at[p] = oid


func _new_object(items: Dictionary, blist: Array) -> int:
	var per := {}
	for k in items.keys():
		per[k] = int(ceil(float(items[k]) / Cfg.HITS_PER_OBJECT))
	var oid := next_obj
	next_obj += 1
	objects[oid] = {"left": items.duplicate(), "per_hit": per, "blocks": blist}
	return oid


# ---------- руда ----------

func _gen_nodes() -> void:
	var plan := [
		[Cfg.ORE_STONE, 30, {"stone": 80}],
		[Cfg.ORE_SULFUR, 12, {"sulfur": 60}],
		[Cfg.ORE_METAL, 14, {"metal_ore": 60, "mvk_ore": 3}],
	]
	for entry in plan:
		var id: int = entry[0]
		var count: int = entry[1]
		var items: Dictionary = entry[2]
		var placed := 0
		var tries := 0
		while placed < count and tries < count * 40:
			tries += 1
			var x := rng.randi_range(4, Cfg.WX - 6)
			var z := rng.randi_range(4, Cfg.WZ - 6)
			var h := heights[z * Cfg.WX + x]
			if h <= Cfg.BEACH_H:
				continue
			var free := true
			for dz in range(-1, 3):
				for dx in range(-1, 3):
					if get_block(x + dx, h + 1, z + dz) != 0:
						free = false
			if not free:
				continue
			var list := []
			for dz in range(-1, 2):
				for dx in range(-1, 2):
					if absi(dx) + absi(dz) == 2 and rng.randf() < 0.5:
						continue
					_put(list, x + dx, h + 1, z + dz, id)
			for dz in range(0, 2):
				for dx in range(0, 2):
					_put(list, x + dx, h + 2, z + dz, id)
			_put(list, x, h + 3, z, id)
			var oid := _new_object(items, list)
			for p in list:
				obj_at[p] = oid
			placed += 1


# ---------- сбор ресурсов ----------

func harvest(pos: Vector3i) -> Dictionary:
	if not obj_at.has(pos):
		return {}
	var oid: int = obj_at[pos]
	var o: Dictionary = objects[oid]
	var gained := {}
	var empty := true
	for item in o["left"].keys():
		var give: int = mini(o["per_hit"][item], o["left"][item])
		o["left"][item] -= give
		gained[item] = give
		if o["left"][item] > 0:
			empty = false
	if empty:
		_remove_object(oid)
	return gained


func _remove_object(oid: int) -> void:
	var o: Dictionary = objects[oid]
	var dirty := {}
	for p in o["blocks"]:
		var v: Vector3i = p
		blocks[idx(v.x, v.y, v.z)] = 0
		obj_at.erase(v)
		var cx := v.x / Cfg.CHUNK
		var cz := v.z / Cfg.CHUNK
		dirty[Vector2i(cx, cz)] = true
		if v.x % Cfg.CHUNK == 0 and cx > 0:
			dirty[Vector2i(cx - 1, cz)] = true
		if v.x % Cfg.CHUNK == Cfg.CHUNK - 1 and cx < Cfg.WX / Cfg.CHUNK - 1:
			dirty[Vector2i(cx + 1, cz)] = true
		if v.z % Cfg.CHUNK == 0 and cz > 0:
			dirty[Vector2i(cx, cz - 1)] = true
		if v.z % Cfg.CHUNK == Cfg.CHUNK - 1 and cz < Cfg.WZ / Cfg.CHUNK - 1:
			dirty[Vector2i(cx, cz + 1)] = true
	objects.erase(oid)
	for k in dirty.keys():
		build_chunk(k.x, k.y)


# ---------- мини-карта ----------

func _make_minimap() -> void:
	var img := Image.create(Cfg.WX, Cfg.WZ, false, Image.FORMAT_RGB8)
	for z in Cfg.WZ:
		for x in Cfg.WX:
			var c := Color(0.30, 0.62, 0.25)
			match biomes[z * Cfg.WX + x]:
				1: c = Color(0.88, 0.93, 1.0)
				2: c = Color(0.95, 0.80, 0.40)
			if heights[z * Cfg.WX + x] <= 9:
				c = Color(0.17, 0.42, 0.70)
			img.set_pixel(x, z, c)
	minimap = ImageTexture.create_from_image(img)


func find_spawn() -> Vector3:
	var cx := Cfg.WX / 2
	var cz := Cfg.WZ / 2
	for r in range(0, 80, 2):
		for a in 16:
			var ang := TAU * a / 16.0
			var x := clampi(cx + int(cos(ang) * r), 6, Cfg.WX - 7)
			var z := clampi(cz + int(sin(ang) * r), 6, Cfg.WZ - 7)
			if biomes[z * Cfg.WX + x] != 0:
				continue
			var h := heights[z * Cfg.WX + x]
			if h <= Cfg.BEACH_H:
				continue
			if get_block(x, h + 1, z) == 0 and get_block(x, h + 2, z) == 0 and get_block(x, h + 3, z) == 0:
				return Vector3(x + 0.5, h + 2.0, z + 0.5)
	return Vector3(cx, 30, cz)


# ---------- меши ----------

func _hash(x: int, y: int, z: int) -> float:
	var n := (x * 73856093) ^ (y * 19349663) ^ (z * 83492791)
	return float(absi(n) % 1000) / 1000.0


func build_chunk(cx: int, cz: int) -> void:
	var key := Vector2i(cx, cz)
	if chunk_nodes.has(key):
		chunk_nodes[key].queue_free()
		chunk_nodes.erase(key)
	var verts := PackedVector3Array()
	var norms := PackedVector3Array()
	var cols := PackedColorArray()
	var inds := PackedInt32Array()
	var x0 := cx * Cfg.CHUNK
	var z0 := cz * Cfg.CHUNK
	for z in range(z0, z0 + Cfg.CHUNK):
		for x in range(x0, x0 + Cfg.CHUNK):
			var ci := z * Cfg.WX + x
			var h := heights[ci]
			var lo := h
			if x > 0:
				lo = mini(lo, heights[ci - 1])
			else:
				lo = 0
			if x < Cfg.WX - 1:
				lo = mini(lo, heights[ci + 1])
			else:
				lo = 0
			if z > 0:
				lo = mini(lo, heights[ci - Cfg.WX])
			else:
				lo = 0
			if z < Cfg.WZ - 1:
				lo = mini(lo, heights[ci + Cfg.WX])
			else:
				lo = 0
			for y in range(maxi(lo, 0), colmax[ci] + 1):
				var id := blocks[idx(x, y, z)]
				if id == 0:
					continue
				var col := Cfg.block_color(id)
				var v := 0.90 + 0.14 * _hash(x, y, z)
				col = Color(col.r * v, col.g * v, col.b * v, 1.0)
				for f in 6:
					var n: Vector3i = FN[f]
					if _solid(x + n.x, y + n.y, z + n.z):
						continue
					var c := Vector3(x + 0.5 + n.x * 0.5, y + 0.5 + n.y * 0.5, z + 0.5 + n.z * 0.5)
					var u := Vector3(FU[f]) * 0.5
					var w := Vector3(FV[f]) * 0.5
					var base := verts.size()
					verts.append(c - u - w)
					verts.append(c - u + w)
					verts.append(c + u + w)
					verts.append(c + u - w)
					var nf := Vector3(n)
					for k in 4:
						norms.append(nf)
						cols.append(col)
					inds.append(base)
					inds.append(base + 1)
					inds.append(base + 2)
					inds.append(base)
					inds.append(base + 2)
					inds.append(base + 3)
	if verts.size() == 0:
		return
	var arr := []
	arr.resize(Mesh.ARRAY_MAX)
	arr[Mesh.ARRAY_VERTEX] = verts
	arr[Mesh.ARRAY_NORMAL] = norms
	arr[Mesh.ARRAY_COLOR] = cols
	arr[Mesh.ARRAY_INDEX] = inds
	var mesh := ArrayMesh.new()
	mesh.add_surface_from_arrays(Mesh.PRIMITIVE_TRIANGLES, arr)
	mesh.surface_set_material(0, mat)
	var mi := MeshInstance3D.new()
	mi.mesh = mesh
	var body := StaticBody3D.new()
	body.set_meta("terrain", true)
	var cs := CollisionShape3D.new()
	var shape := mesh.create_trimesh_shape()
	if shape != null:
		shape.backface_collision = true
	cs.shape = shape
	body.add_child(cs)
	mi.add_child(body)
	add_child(mi)
	chunk_nodes[key] = mi
