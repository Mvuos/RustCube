class_name Builder
extends Node3D
# Строительство как в расте: сетка 3x3, фундамент -> стены -> перекрытия,
# уровни: солома -> дерево -> камень -> металл -> МВК (улучшение киянкой).

const S := 3.0          # размер клетки (блоков)
const T := 0.25         # толщина стены
const DOOR_W := 1.3
const DOOR_H := 2.3

var world: VoxelWorld
var pieces := {}        # key -> info
var found := {}         # Vector2i -> {top}
var ghost: Node3D
var ghost_key := ""
var ghost_info := {}
var ghost_ok_mat: StandardMaterial3D
var ghost_bad_mat: StandardMaterial3D
var tier_mats := {}


func _ready() -> void:
	for t in Cfg.TIERS:
		var m := StandardMaterial3D.new()
		m.albedo_color = Cfg.tier_color(t)
		m.roughness = 0.9
		tier_mats[t] = m
	ghost_ok_mat = _ghost_mat(Color(0.2, 1.0, 0.3, 0.45))
	ghost_bad_mat = _ghost_mat(Color(1.0, 0.2, 0.2, 0.45))


func _ghost_mat(c: Color) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


# ---------- клетки и рёбра ----------

func cell_of(x: float, z: float) -> Vector2i:
	return Vector2i(floori((x + 1.0) / S), floori((z + 1.0) / S))


func cell_center(c: Vector2i) -> Vector2:
	return Vector2(c.x * S + 0.5, c.y * S + 0.5)


# side: 0=восток 1=юг 2=запад 3=север -> (клетка, ребро 0/1)
func norm_edge(c: Vector2i, side: int) -> Array:
	match side:
		0: return [c, 0]
		1: return [c, 1]
		2: return [Vector2i(c.x - 1, c.y), 0]
	return [Vector2i(c.x, c.y - 1), 1]


func wkey(c: Vector2i, e: int, l: int) -> String:
	return "w%d_%d_%d_%d" % [c.x, c.y, e, l]


func fkey(c: Vector2i) -> String:
	return "f%d_%d" % [c.x, c.y]


func flkey(c: Vector2i, l: int) -> String:
	return "fl%d_%d_%d" % [c.x, c.y, l]


func wall_pos(c: Vector2i, e: int) -> Vector3:
	var cc := cell_center(c)
	if e == 0:
		return Vector3(cc.x + S / 2.0, 0, cc.y)
	return Vector3(cc.x, 0, cc.y + S / 2.0)


# ---------- проверка, куда можно ставить ----------

func compute_target(res: Dictionary, ptype: String) -> Dictionary:
	var none := {"ok": false}
	if res.is_empty():
		return none
	var p: Vector3 = res["position"]
	var n: Vector3 = res["normal"]
	var col = res["collider"]
	var hp = null
	if col != null and col.has_meta("pkey"):
		hp = pieces.get(col.get_meta("pkey"), null)

	if ptype == "foundation":
		var cell := cell_of(p.x, p.z)
		if hp != null:
			if hp["type"] != "foundation":
				return none
			var c0: Vector2i = hp["cell"]
			var cc := cell_center(c0)
			var ox := p.x - cc.x
			var oz := p.z - cc.y
			if absf(ox) > absf(oz):
				cell = Vector2i(c0.x + (1 if ox > 0 else -1), c0.y)
			else:
				cell = Vector2i(c0.x, c0.y + (1 if oz > 0 else -1))
		elif col == null or not col.has_meta("terrain"):
			return none
		if found.has(cell):
			return none
		var minT := 999.0
		var maxT := -999.0
		for z in range(cell.y * 3 - 1, cell.y * 3 + 2):
			for x in range(cell.x * 3 - 1, cell.x * 3 + 2):
				var tt := world.surface_top(x, z)
				minT = minf(minT, tt)
				maxT = maxf(maxT, tt)
		var top := maxT
		for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
			var nc: Vector2i = cell + d
			if found.has(nc):
				top = found[nc]["top"]
		var ok := true
		if maxT - top > 1.0 or top - minT > 4.0:
			ok = false
		# препятствия (деревья, руда) внутри
		for z in range(cell.y * 3 - 1, cell.y * 3 + 2):
			for x in range(cell.x * 3 - 1, cell.x * 3 + 2):
				for y in range(int(ceil(top)), int(ceil(top)) + 3):
					if world.get_block(x, y, z) != 0:
						ok = false
		return {"ok": ok, "type": ptype, "key": fkey(cell), "cell": cell, "top": top,
			"bottom": minf(minT, top) - 1.0, "base": top, "level": 0, "tier": "twig"}

	if ptype == "wall" or ptype == "doorway":
		if hp == null or n.y < 0.5:
			return none
		var cell: Vector2i
		var level := 0
		if hp["type"] == "foundation":
			cell = hp["cell"]
		elif hp["type"] == "floor":
			cell = hp["cell"]
			level = hp["level"]
		else:
			return none
		var cc := cell_center(cell)
		var ox := p.x - cc.x
		var oz := p.z - cc.y
		var side := 0
		if absf(ox) > absf(oz):
			side = 0 if ox > 0 else 2
		else:
			side = 1 if oz > 0 else 3
		var ed := norm_edge(cell, side)
		var key := wkey(ed[0], ed[1], level)
		return {"ok": not pieces.has(key), "type": ptype, "key": key, "cell": ed[0], "edge": ed[1],
			"level": level, "base": hp["base"], "tier": "twig"}

	if ptype == "floor":
		if hp == null:
			return none
		var cell: Vector2i
		var level := 1
		if hp["type"] == "wall" or hp["type"] == "doorway":
			level = hp["level"] + 1
			var wc: Vector2i = hp["cell"]
			var wp := wall_pos(wc, hp["edge"])
			if hp["edge"] == 0:
				cell = Vector2i(wc.x + (1 if p.x > wp.x else 0), wc.y)
			else:
				cell = Vector2i(wc.x, wc.y + (1 if p.z > wp.z else 0))
		elif hp["type"] == "floor":
			level = hp["level"]
			var c0: Vector2i = hp["cell"]
			var cc := cell_center(c0)
			var ox := p.x - cc.x
			var oz := p.z - cc.y
			if absf(ox) > absf(oz):
				cell = Vector2i(c0.x + (1 if ox > 0 else -1), c0.y)
			else:
				cell = Vector2i(c0.x, c0.y + (1 if oz > 0 else -1))
		else:
			return none
		var key := flkey(cell, level)
		var ok := not pieces.has(key) and _floor_supported(cell, level)
		return {"ok": ok, "type": ptype, "key": key, "cell": cell, "level": level, "base": hp["base"], "tier": "twig"}

	if ptype == "door":
		if hp == null or hp["type"] != "doorway":
			return none
		var dk: String = "d" + str(hp["key"])
		return {"ok": not pieces.has(dk), "type": ptype, "key": dk, "wall": hp["key"], "tier": "wood"}
	return none


func _floor_supported(cell: Vector2i, level: int) -> bool:
	var lv := level - 1
	var edges := [
		wkey(cell, 0, lv), wkey(cell, 1, lv),
		wkey(Vector2i(cell.x - 1, cell.y), 0, lv), wkey(Vector2i(cell.x, cell.y - 1), 1, lv),
	]
	for k in edges:
		if pieces.has(k):
			return true
	for d in [Vector2i(1, 0), Vector2i(-1, 0), Vector2i(0, 1), Vector2i(0, -1)]:
		if pieces.has(flkey(cell + d, level)):
			return true
	return false


# ---------- призрак ----------

func update_ghost(res: Dictionary, ptype: String) -> void:
	var info := compute_target(res, ptype)
	if not info.has("type"):
		hide_ghost()
		return
	ghost_info = info
	var sig := str(info.get("key", "")) + ptype
	if ghost == null or ghost_key != sig:
		if ghost != null:
			ghost.queue_free()
		ghost = Node3D.new()
		add_child(ghost)
		_build_geometry(info, ghost, true)
		ghost_key = sig
	ghost.visible = true
	var mat: StandardMaterial3D = ghost_ok_mat if info["ok"] else ghost_bad_mat
	for ch in _all_meshes(ghost):
		ch.material_override = mat


func hide_ghost() -> void:
	if ghost != null:
		ghost.visible = false
	ghost_info = {}


func _all_meshes(root: Node) -> Array:
	var out := []
	for ch in root.get_children():
		if ch is MeshInstance3D:
			out.append(ch)
		out.append_array(_all_meshes(ch))
	return out


# ---------- геометрия ----------

func _box(parent: Node3D, size: Vector3, pos: Vector3, material: Material, key: String, ghost_only: bool, meshes: Array) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	if material != null:
		mi.material_override = material
	parent.add_child(mi)
	meshes.append(mi)
	if not ghost_only:
		var body := StaticBody3D.new()
		body.set_meta("pkey", key)
		var cs := CollisionShape3D.new()
		var sh := BoxShape3D.new()
		sh.size = size
		cs.shape = sh
		body.add_child(cs)
		body.position = pos
		parent.add_child(body)


func _build_geometry(info: Dictionary, root: Node3D, ghost_only: bool) -> Array:
	var meshes := []
	var ptype: String = info["type"]
	var tier: String = info["tier"]
	var m: Material = null if ghost_only else tier_mats[tier]
	var key: String = info.get("key", "")
	if ptype == "foundation":
		var c: Vector2i = info["cell"]
		var cc := cell_center(c)
		var top: float = info["top"]
		var bot: float = info["bottom"]
		_box(root, Vector3(S, top - bot, S), Vector3(cc.x, (top + bot) / 2.0, cc.y), m, key, ghost_only, meshes)
	elif ptype == "floor":
		var c: Vector2i = info["cell"]
		var cc := cell_center(c)
		var y: float = info["base"] + info["level"] * S
		_box(root, Vector3(S, 0.3, S), Vector3(cc.x, y - 0.15, cc.y), m, key, ghost_only, meshes)
	elif ptype == "wall" or ptype == "doorway":
		var e: int = info["edge"]
		var wp := wall_pos(info["cell"], e)
		root.position = Vector3(wp.x, info["base"] + info["level"] * S, wp.z)
		root.rotation.y = PI / 2.0 if e == 0 else 0.0
		if ptype == "wall":
			_box(root, Vector3(S, S, T), Vector3(0, S / 2.0, 0), m, key, ghost_only, meshes)
		else:
			var pw := (S - DOOR_W) / 2.0
			var off := DOOR_W / 2.0 + pw / 2.0
			_box(root, Vector3(pw, S, T), Vector3(-off, S / 2.0, 0), m, key, ghost_only, meshes)
			_box(root, Vector3(pw, S, T), Vector3(off, S / 2.0, 0), m, key, ghost_only, meshes)
			_box(root, Vector3(DOOR_W, S - DOOR_H, T), Vector3(0, DOOR_H + (S - DOOR_H) / 2.0, 0), m, key, ghost_only, meshes)
	elif ptype == "door":
		var wk: String = info["wall"]
		var w: Dictionary = pieces[wk]
		var wroot: Node3D = w["node"]
		if ghost_only:
			root.position = wroot.position
			root.rotation = wroot.rotation
			_box(root, Vector3(DOOR_W - 0.04, DOOR_H, 0.1), Vector3(0, DOOR_H / 2.0, 0), null, key, true, meshes)
		else:
			var pivot := Node3D.new()
			pivot.position = Vector3(-DOOR_W / 2.0, 0, 0)
			wroot.add_child(pivot)
			var dm := StandardMaterial3D.new()
			dm.albedo_color = Color(0.5, 0.33, 0.16)
			_box(pivot, Vector3(DOOR_W - 0.04, DOOR_H, 0.1), Vector3(DOOR_W / 2.0, DOOR_H / 2.0, 0), dm, key, false, meshes)
			info["pivot"] = pivot
	return meshes


# ---------- постановка и улучшение ----------

func place(game) -> String:
	if ghost_info.is_empty() or not ghost_info.get("ok", false):
		return "Сюда нельзя"
	var info: Dictionary = ghost_info.duplicate()
	var ptype: String = info["type"]
	var cost := Cfg.piece_cost(ptype, info["tier"])
	var item := Cfg.piece_item(ptype, info["tier"])
	if not game.has_item(item, cost):
		return "Нужно %d %s" % [cost, Cfg.ITEM_NAMES[item]]
	game.spend(item, cost)
	var root := Node3D.new()
	add_child(root)
	info["node"] = root
	info["open"] = false
	if ptype == "door":
		var w: Dictionary = pieces[info["wall"]]
		info["node"] = w["node"]
		info["meshes"] = _build_geometry(info, root, false)
		root.queue_free()
	else:
		info["meshes"] = _build_geometry(info, root, false)
	pieces[info["key"]] = info
	if ptype == "foundation":
		found[info["cell"]] = {"top": info["top"]}
	hide_ghost()
	ghost_key = ""
	return ""


func upgrade(key: String, game) -> String:
	if not pieces.has(key):
		return ""
	var info: Dictionary = pieces[key]
	var ptype: String = info["type"]
	if ptype == "door":
		return "Дверь не улучшается"
	var ti := Cfg.TIERS.find(info["tier"])
	if ti >= Cfg.TIERS.size() - 1:
		return "Уже МВК"
	var nt: String = Cfg.TIERS[ti + 1]
	var cost := Cfg.piece_cost(ptype, nt)
	var item := Cfg.piece_item(ptype, nt)
	if not game.has_item(item, cost):
		return "Нужно %d %s" % [cost, Cfg.ITEM_NAMES[item]]
	game.spend(item, cost)
	info["tier"] = nt
	for mi in info["meshes"]:
		mi.material_override = tier_mats[nt]
	return "Улучшено: " + Cfg.TIER_NAMES[nt]


func upgrade_hint(key: String) -> String:
	if not pieces.has(key):
		return ""
	var info: Dictionary = pieces[key]
	if info["type"] == "door":
		return ""
	var ti := Cfg.TIERS.find(info["tier"])
	if ti >= Cfg.TIERS.size() - 1:
		return Cfg.PIECE_NAMES[info["type"]] + ": МВК (максимум)"
	var nt: String = Cfg.TIERS[ti + 1]
	return "%s (%s) -> %s: %d %s" % [Cfg.PIECE_NAMES[info["type"]], Cfg.TIER_NAMES[info["tier"]],
		Cfg.TIER_NAMES[nt], Cfg.piece_cost(info["type"], nt), Cfg.ITEM_NAMES[Cfg.piece_item(info["type"], nt)]]


func toggle_door(key: String) -> void:
	if not pieces.has(key):
		return
	var info: Dictionary = pieces[key]
	if info["type"] != "door":
		return
	info["open"] = not info["open"]
	var pivot: Node3D = info["pivot"]
	var tw := create_tween()
	tw.tween_property(pivot, "rotation:y", -PI / 2.0 if info["open"] else 0.0, 0.35).set_trans(Tween.TRANS_SINE)


func piece_at_collider(col) -> String:
	if col != null and col.has_meta("pkey"):
		return col.get_meta("pkey")
	return ""
