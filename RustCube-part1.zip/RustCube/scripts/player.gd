class_name Player
extends CharacterBody3D

const SPEED := 5.0
const SPRINT := 7.0
const JUMP := 7.0
const GRAV := 24.0
const REACH_TOOL := 3.3
const REACH_BUILD := 7.0

var game
var ui
var world
var builder
var yaw := 0.0
var pitch := 0.0
var cam: Camera3D
var hand: Node3D
var vm := {}
var vm_base := {}
var current := ""
var fly := false
var cooldown := 0.0
var ak_ammo := 30
var reload_left := 0.0
var flash_t := 0.0
var recoil := 0.0
var bob_t := 0.0
var last_res := {}


func _ready() -> void:
	var cs := CollisionShape3D.new()
	var cap := CapsuleShape3D.new()
	cap.radius = 0.35
	cap.height = 1.7
	cs.shape = cap
	cs.position = Vector3(0, 0.85, 0)
	add_child(cs)
	cam = Camera3D.new()
	cam.position = Vector3(0, 1.55, 0)
	cam.fov = 72.0
	cam.near = 0.05
	cam.far = 240.0
	add_child(cam)
	hand = Node3D.new()
	cam.add_child(hand)
	_add_vm("rock", ViewModels.rock(), Vector3(0.28, -0.25, -0.5), Vector3(0, 0, 0), 1.0)
	_add_vm("torch", ViewModels.torch(), Vector3(0.28, -0.34, -0.5), Vector3(-15, 0, -8), 1.0)
	_add_vm("hammer", ViewModels.hammer(), Vector3(0.30, -0.30, -0.5), Vector3(-30, 0, 0), 1.0)
	_add_vm("plan", ViewModels.plan(), Vector3(0.18, -0.22, -0.5), Vector3(-65, 0, 0), 1.0)
	_add_vm("ak", AK47Model.build(), Vector3(0.22, -0.20, -0.42), Vector3(0, 0, 0), 0.8)
	cam.make_current()


func setup(g, u, w, b) -> void:
	game = g
	ui = u
	world = w
	builder = b


func _add_vm(id: String, node: Node3D, pos: Vector3, rot: Vector3, sc: float) -> void:
	node.position = pos
	node.rotation_degrees = rot
	node.scale = Vector3.ONE * sc
	node.visible = false
	hand.add_child(node)
	vm[id] = node
	vm_base[id] = {"pos": pos, "rot": rot}


func equip(id: String) -> void:
	current = id
	for k in vm.keys():
		vm[k].visible = (k == id)
		vm[k].position = vm_base[k]["pos"]
		vm[k].rotation_degrees = vm_base[k]["rot"]
	if id != "plan" and builder != null:
		builder.hide_ghost()
	reload_left = 0.0


func respawn() -> void:
	position = world.find_spawn()
	velocity = Vector3.ZERO


func _physics_process(delta: float) -> void:
	if ui == null or ui.screen != "game":
		return
	var mv: Vector2 = ui.move_vec
	var spd := SPRINT if mv.length() > 0.92 else SPEED
	if fly:
		var d: Vector3 = cam.global_transform.basis * Vector3(mv.x, 0, -mv.y)
		velocity = d * spd * 1.6
		if ui.held.get("jump", false):
			velocity.y += 8.0
		if ui.held.get("down", false):
			velocity.y -= 8.0
	else:
		var d2: Vector3 = transform.basis * Vector3(mv.x, 0, -mv.y)
		velocity.x = d2.x * spd
		velocity.z = d2.z * spd
		if is_on_floor():
			velocity.y = 0.0
			if ui.held.get("jump", false):
				velocity.y = JUMP
			elif is_on_wall() and mv.length() > 0.3:
				velocity.y = JUMP
		else:
			velocity.y -= GRAV * delta
	move_and_slide()
	if global_position.y < -30.0:
		respawn()


func _ray(dist: float) -> Dictionary:
	var from := cam.global_position
	var to := from + (-cam.global_transform.basis.z) * dist
	var q := PhysicsRayQueryParameters3D.create(from, to)
	q.exclude = [get_rid()]
	return get_world_3d().direct_space_state.intersect_ray(q)


func _process(delta: float) -> void:
	if ui == null or ui.screen != "game":
		if builder != null:
			builder.hide_ghost()
		return
	# обзор
	var lk: Vector2 = ui.consume_look()
	yaw -= lk.x * 0.0035
	pitch = clampf(pitch - lk.y * 0.0035, -1.45, 1.45)
	rotation.y = yaw
	cam.rotation.x = pitch
	cooldown -= delta
	last_res = _ray(REACH_BUILD)

	# подсказки и призрак постройки
	ui.hint = ""
	ui.prompt = ""
	var key := ""
	if not last_res.is_empty():
		key = builder.piece_at_collider(last_res["collider"])
	if current == "plan":
		builder.update_ghost(last_res, ui.build_piece)
		var gi: Dictionary = builder.ghost_info
		if not gi.is_empty():
			var item := Cfg.piece_item(gi["type"], gi["tier"])
			var cost := Cfg.piece_cost(gi["type"], gi["tier"])
			ui.hint = "%s: %d %s" % [Cfg.PIECE_NAMES[gi["type"]], cost, Cfg.ITEM_NAMES[item]]
			if not gi["ok"]:
				ui.hint += "  (сюда нельзя)"
		else:
			ui.hint = "Выбрано: " + Cfg.PIECE_NAMES[ui.build_piece] + "  (наведи на землю/фундамент)"
	elif current == "hammer" and key != "":
		if cam.global_position.distance_to(last_res["position"]) < 5.0:
			ui.hint = builder.upgrade_hint(key)
	if key != "" and builder.pieces.has(key) and builder.pieces[key]["type"] == "door":
		if cam.global_position.distance_to(last_res["position"]) < 4.0:
			ui.prompt = "Дверь"

	# нажатия кнопок
	for ev in ui.pressed:
		var e: String = ev
		if e.begins_with("slot"):
			game.select_slot(int(e.substr(4)))
			continue
		match e:
			"use":
				_use_press()
			"interact":
				if ui.prompt != "":
					builder.toggle_door(key)
			"reload":
				_reload()
			"radial":
				ui.screen = "radial"
			"pause":
				ui.screen = "pause"
			"craft":
				ui.screen = "craft"
	ui.pressed.clear()

	# автоогонь АК
	if current == "ak":
		if reload_left > 0.0:
			reload_left -= delta
			if reload_left <= 0.0:
				ak_ammo = 30
		elif ui.held.get("use", false) and cooldown <= 0.0:
			_fire()
	if flash_t > 0.0:
		flash_t -= delta
		if flash_t <= 0.0 and vm["ak"].has_node("Muzzle/Flash"):
			vm["ak"].get_node("Muzzle/Flash").visible = false
	_update_viewmodel(delta)


func _use_press() -> void:
	match current:
		"rock":
			_hit_rock()
		"hammer":
			_hammer()
		"plan":
			var msg: String = builder.place(game)
			if msg != "":
				game.notify(msg)
		"torch":
			var l: OmniLight3D = vm["torch"].get_node("Light")
			l.visible = not l.visible


func _swing(node: Node3D) -> void:
	var base: Vector3 = vm_base[current]["rot"]
	var tw := create_tween()
	tw.tween_property(node, "rotation_degrees:x", base.x - 55.0, 0.12)
	tw.tween_property(node, "rotation_degrees:x", base.x, 0.2)


func _hit_rock() -> void:
	if cooldown > 0.0:
		return
	cooldown = 0.5
	_swing(vm["rock"])
	var res := _ray(REACH_TOOL)
	if res.is_empty():
		return
	var col = res["collider"]
	if col != null and col.has_meta("terrain"):
		var pt: Vector3 = res["position"] - res["normal"] * 0.05
		var v := Vector3i(floori(pt.x), floori(pt.y), floori(pt.z))
		var gained: Dictionary = world.harvest(v)
		for k in gained.keys():
			game.add_item(k, gained[k])


func _hammer() -> void:
	if cooldown > 0.0:
		return
	cooldown = 0.4
	_swing(vm["hammer"])
	var res := _ray(5.0)
	if res.is_empty():
		return
	var key: String = builder.piece_at_collider(res["collider"])
	if key != "":
		var msg: String = builder.upgrade(key, game)
		if msg != "":
			game.notify(msg)


func _reload() -> void:
	if current == "ak" and reload_left <= 0.0 and ak_ammo < 30:
		reload_left = 1.6


func _fire() -> void:
	if ak_ammo <= 0:
		_reload()
		return
	ak_ammo -= 1
	cooldown = 0.1
	flash_t = 0.045
	recoil = 1.0
	pitch = clampf(pitch + 0.004, -1.45, 1.45)
	var ak: Node3D = vm["ak"]
	if ak.has_node("Muzzle/Flash"):
		ak.get_node("Muzzle/Flash").visible = true
	var res := _ray(120.0)
	if not res.is_empty():
		_impact(res["position"])


func _impact(pos: Vector3) -> void:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = Vector3(0.1, 0.1, 0.1)
	mi.mesh = bm
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(1.0, 0.8, 0.3)
	m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mi.material_override = m
	get_tree().current_scene.add_child(mi)
	mi.global_position = pos
	get_tree().create_timer(0.25).timeout.connect(mi.queue_free)


func _update_viewmodel(delta: float) -> void:
	if current == "" or not vm.has(current):
		return
	var n: Node3D = vm[current]
	var b = vm_base[current]
	var moving := Vector2(velocity.x, velocity.z).length() > 0.5 and is_on_floor()
	bob_t += delta * (9.0 if moving else 2.0)
	var amp := 0.012 if moving else 0.003
	var p: Vector3 = b["pos"] + Vector3(cos(bob_t * 0.5) * amp, absf(sin(bob_t * 0.5)) * amp, 0.0)
	recoil = move_toward(recoil, 0.0, delta * 9.0)
	if current == "ak":
		p.z += recoil * 0.06
		if reload_left > 0.0:
			p.y -= sin((1.0 - reload_left / 1.6) * PI) * 0.18
		n.position = p
		n.rotation_degrees = b["rot"] + Vector3(recoil * 4.0, 0, 0)
	else:
		n.position = p
	if current == "torch":
		var l: OmniLight3D = n.get_node("Light")
		l.light_energy = 1.5 + sin(Time.get_ticks_msec() * 0.02) * 0.15
