class_name GameUI
extends Control
# Весь интерфейс рисуется кодом и управляется сенсорными событиями (мультитач).

signal start_requested(mode: String, seed_val: int)
signal craft_requested(recipe: String)
signal quit_requested
signal fly_toggled

var screen := "main":
	set(value):
		screen = value
		_release_all()

var game
var font: Font
var u := 1.0
var move_vec := Vector2.ZERO
var look_acc := Vector2.ZERO
var held := {}
var pressed := []
var build_piece := "wall"
var hint := ""
var prompt := ""
var touches := {}
var joy_touch := -1
var joy_origin := Vector2.ZERO
var joy_pos := Vector2.ZERO
var notes := []
var load_value := 0.0
var load_text := ""
var menu_seed := 0


func _ready() -> void:
	set_anchors_preset(Control.PRESET_FULL_RECT)
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	if ResourceLoader.exists("res://fonts/font.ttf"):
		font = load("res://fonts/font.ttf")
	else:
		font = ThemeDB.fallback_font
	menu_seed = randi() % 1000000


func _release_all() -> void:
	held.clear()
	touches.clear()
	joy_touch = -1
	move_vec = Vector2.ZERO
	look_acc = Vector2.ZERO


func consume_look() -> Vector2:
	var v := look_acc
	look_acc = Vector2.ZERO
	return v


func notify(text: String) -> void:
	notes.append([text, 2.6])
	if notes.size() > 5:
		notes.pop_front()


func on_progress(value: float, text: String) -> void:
	load_value = value
	load_text = text


func _process(delta: float) -> void:
	var s := get_viewport_rect().size
	u = minf(s.x, s.y) / 720.0
	for n in notes:
		n[1] -= delta
	while notes.size() > 0 and notes[0][1] <= 0.0:
		notes.pop_front()
	queue_redraw()


# ---------------- раскладка ----------------

func _c(name: String, c: Vector2, r: float, label: String) -> Dictionary:
	return {"name": name, "c": c, "r": r, "label": label}


func _r(name: String, rect: Rect2, label: String) -> Dictionary:
	return {"name": name, "rect": rect, "label": label}


func _use_label() -> String:
	match game.current_item():
		"rock": return "Удар"
		"ak": return "Огонь"
		"plan": return "Ставить"
		"hammer": return "Улучшить"
		"torch": return "Вкл/Выкл"
	return "-"


func _game_buttons() -> Array:
	var s := get_viewport_rect().size
	var a := []
	a.append(_c("use", Vector2(s.x - 130 * u, s.y - 150 * u), 74 * u, _use_label()))
	a.append(_c("jump", Vector2(s.x - 285 * u, s.y - 85 * u), 52 * u, "Прыжок"))
	if prompt != "":
		a.append(_c("interact", Vector2(s.x - 285 * u, s.y - 215 * u), 46 * u, prompt))
	if game.current_item() == "ak":
		a.append(_c("reload", Vector2(s.x - 130 * u, s.y - 300 * u), 40 * u, "Заряд"))
	if game.current_item() == "plan":
		a.append(_c("radial", Vector2(s.x - 130 * u, s.y - 300 * u), 44 * u, "Меню"))
	if game.player != null and game.player.fly:
		a.append(_c("down", Vector2(s.x - 410 * u, s.y - 85 * u), 46 * u, "Вниз"))
	a.append(_c("pause", Vector2(s.x - 48 * u, 48 * u), 32 * u, "II"))
	if not game.sandbox:
		a.append(_c("craft", Vector2(s.x - 130 * u, 48 * u), 34 * u, "Крафт"))
	return a


func _slot_rect(i: int) -> Rect2:
	var s := get_viewport_rect().size
	var w := 66.0 * u
	var gap := 8.0 * u
	var total := 6.0 * w + 5.0 * gap
	return Rect2(s.x / 2.0 - total / 2.0 + i * (w + gap), s.y - 80.0 * u, w, w)


func _menu_buttons() -> Array:
	var s := get_viewport_rect().size
	var a := []
	var w := 380.0 * u
	var h := 78.0 * u
	var cx := s.x / 2.0 - w / 2.0
	match screen:
		"main":
			a.append(_r("survival", Rect2(cx, s.y * 0.38, w, h), "Выживание"))
			a.append(_r("sandbox", Rect2(cx, s.y * 0.38 + 96 * u, w, h), "Песочница"))
			a.append(_r("newmap", Rect2(cx, s.y * 0.38 + 192 * u, w, 60 * u), "Другая карта (сид %d)" % menu_seed))
		"pause":
			a.append(_r("resume", Rect2(cx, s.y * 0.30, w, h), "Продолжить"))
			var i := 1
			if game.sandbox:
				var fl := "Полёт: выкл"
				if game.player != null and game.player.fly:
					fl = "Полёт: вкл"
				a.append(_r("flytoggle", Rect2(cx, s.y * 0.30 + 96 * u, w, h), fl))
				i = 2
			a.append(_r("tomenu", Rect2(cx, s.y * 0.30 + 96 * u * i, w, h), "В главное меню"))
		"craft":
			var keys := Cfg.RECIPES.keys()
			for i in keys.size():
				a.append(_r("make_" + keys[i], Rect2(s.x / 2.0 + 150 * u, s.y * 0.27 + i * 90 * u, 170 * u, 60 * u), "Создать"))
			a.append(_r("close", Rect2(s.x / 2.0 - 100 * u, s.y * 0.27 + keys.size() * 90 * u + 20 * u, 200 * u, 60 * u), "Закрыть"))
	return a


# ---------------- ввод ----------------

func _input(e: InputEvent) -> void:
	if e is InputEventScreenTouch:
		if e.pressed:
			_down(e.index, e.position)
		else:
			_up(e.index)
	elif e is InputEventScreenDrag:
		_drag(e.index, e.position, e.relative)


func _down(idx: int, pos: Vector2) -> void:
	match screen:
		"game":
			_down_game(idx, pos)
		"radial":
			_down_radial(pos)
		"main", "pause", "craft":
			for b in _menu_buttons():
				if b["rect"].has_point(pos):
					_menu_action(b["name"])
					return


func _down_game(idx: int, pos: Vector2) -> void:
	for b in _game_buttons():
		if pos.distance_to(b["c"]) <= b["r"]:
			held[b["name"]] = true
			pressed.append(b["name"])
			touches[idx] = {"role": "btn", "name": b["name"]}
			return
	for i in 6:
		if _slot_rect(i).has_point(pos):
			pressed.append("slot%d" % i)
			touches[idx] = {"role": "slot"}
			return
	var s := get_viewport_rect().size
	if pos.x < s.x * 0.5 and joy_touch == -1:
		joy_touch = idx
		joy_origin = pos
		joy_pos = pos
		touches[idx] = {"role": "joy"}
	else:
		touches[idx] = {"role": "look"}


func _drag(idx: int, pos: Vector2, rel: Vector2) -> void:
	if screen != "game" or not touches.has(idx):
		return
	var role: String = touches[idx]["role"]
	if role == "look":
		look_acc += rel / u
	elif role == "joy":
		joy_pos = pos
		var v := (joy_pos - joy_origin) / (90.0 * u)
		if v.length() > 1.0:
			v = v.normalized()
			joy_origin = joy_pos - v * 90.0 * u
		if v.length() < 0.12:
			move_vec = Vector2.ZERO
		else:
			move_vec = Vector2(v.x, -v.y)


func _up(idx: int) -> void:
	if not touches.has(idx):
		return
	var t: Dictionary = touches[idx]
	if t["role"] == "btn":
		held[t["name"]] = false
	elif t["role"] == "joy":
		joy_touch = -1
		move_vec = Vector2.ZERO
	touches.erase(idx)


func _down_radial(pos: Vector2) -> void:
	var s := get_viewport_rect().size
	var c := s / 2.0
	var d := pos.distance_to(c)
	var n := Cfg.BUILD_MENU.size()
	if d > 250.0 * u or d < 60.0 * u:
		screen = "game"
		return
	# угол от вертикали вверх по часовой стрелке
	var v := pos - c
	var a := fposmod(atan2(v.x, -v.y) + PI / n, TAU)
	var i := int(floor(a / (TAU / n))) % n
	build_piece = Cfg.BUILD_MENU[i]
	screen = "game"


func _menu_action(name: String) -> void:
	match name:
		"survival":
			start_requested.emit("survival", menu_seed)
		"sandbox":
			start_requested.emit("sandbox", menu_seed)
		"newmap":
			menu_seed = randi() % 1000000
		"resume", "close":
			screen = "game"
		"flytoggle":
			fly_toggled.emit()
			screen = "game"
		"tomenu":
			quit_requested.emit()
		_:
			if name.begins_with("make_"):
				craft_requested.emit(name.substr(5))


# ---------------- рисование ----------------

func _t(text: String, pos: Vector2, size: float, col: Color = Color.WHITE, align: int = HORIZONTAL_ALIGNMENT_LEFT, width: float = -1.0) -> void:
	draw_string(font, pos + Vector2(1.5, 1.5) * u, text, align, width, int(size), Color(0, 0, 0, 0.7))
	draw_string(font, pos, text, align, width, int(size), col)


func _draw_circle_btn(b: Dictionary, active: bool) -> void:
	var c: Vector2 = b["c"]
	var r: float = b["r"]
	draw_circle(c, r, Color(0, 0, 0, 0.45 if not active else 0.7))
	draw_arc(c, r, 0.0, TAU, 40, Color(1, 1, 1, 0.7), 3.0 * u)
	var fs := clampf(r * 0.34, 12.0, 26.0 * u)
	_t(b["label"], Vector2(c.x - r, c.y + fs * 0.35), fs, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, r * 2.0)


func _draw_rect_btn(b: Dictionary, size: float) -> void:
	var rc: Rect2 = b["rect"]
	draw_rect(rc, Color(0.12, 0.14, 0.12, 0.92))
	draw_rect(rc, Color(0.7, 0.9, 0.5, 0.9), false, 3.0 * u)
	_t(b["label"], Vector2(rc.position.x, rc.position.y + rc.size.y / 2.0 + size * 0.35), size, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)


func _draw() -> void:
	var s := get_viewport_rect().size
	match screen:
		"main":
			_draw_main(s)
		"loading":
			draw_rect(Rect2(Vector2.ZERO, s), Color(0.07, 0.1, 0.07))
			_t("Генерация мира", Vector2(0, s.y * 0.42), 40 * u, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, s.x)
			var bw := 520.0 * u
			var bx := s.x / 2.0 - bw / 2.0
			draw_rect(Rect2(bx, s.y * 0.52, bw, 28 * u), Color(0.2, 0.2, 0.2))
			draw_rect(Rect2(bx, s.y * 0.52, bw * load_value, 28 * u), Color(0.5, 0.85, 0.3))
			_t(load_text, Vector2(0, s.y * 0.52 + 70 * u), 24 * u, Color(0.8, 0.9, 0.8), HORIZONTAL_ALIGNMENT_CENTER, s.x)
		_:
			if game.player != null:
				_draw_hud(s)
			if screen == "radial":
				_draw_radial(s)
			elif screen == "pause" or screen == "craft":
				draw_rect(Rect2(Vector2.ZERO, s), Color(0, 0, 0, 0.6))
				if screen == "craft":
					_draw_craft(s)
				for b in _menu_buttons():
					_draw_rect_btn(b, 30 * u)


func _draw_main(s: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, s), Color(0.09, 0.14, 0.09))
	for i in 12:
		var cx := fposmod(i * 193.0 * u, s.x)
		var h := (60.0 + (i * 37) % 90) * u
		draw_rect(Rect2(cx, s.y - h, 90 * u, h), Color(0.15 + 0.01 * i, 0.3, 0.14))
	_t("RustCube", Vector2(0, s.y * 0.2), 72 * u, Color(0.9, 0.95, 0.7), HORIZONTAL_ALIGNMENT_CENTER, s.x)
	_t("Раст в стиле майнкрафта", Vector2(0, s.y * 0.2 + 46 * u), 26 * u, Color(0.8, 0.85, 0.8), HORIZONTAL_ALIGNMENT_CENTER, s.x)
	for b in _menu_buttons():
		_draw_rect_btn(b, 30 * u if b["name"] != "newmap" else 22 * u)
	_t("Часть 1: биомы, стройка, песочница, АК", Vector2(0, s.y - 24 * u), 20 * u, Color(0.7, 0.8, 0.7), HORIZONTAL_ALIGNMENT_CENTER, s.x)


func _draw_craft(s: Vector2) -> void:
	var keys := Cfg.RECIPES.keys()
	var panel := Rect2(s.x / 2.0 - 340 * u, s.y * 0.27 - 60 * u, 680 * u, keys.size() * 90 * u + 170 * u)
	draw_rect(panel, Color(0.1, 0.12, 0.1, 0.95))
	draw_rect(panel, Color(0.7, 0.9, 0.5), false, 3 * u)
	_t("Крафт", Vector2(panel.position.x, panel.position.y + 40 * u), 34 * u, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, panel.size.x)
	for i in keys.size():
		var r: Dictionary = Cfg.RECIPES[keys[i]]
		var y := s.y * 0.27 + i * 90 * u
		_t(r["name"], Vector2(s.x / 2.0 - 320 * u, y + 28 * u), 26 * u)
		var parts := []
		for it in r["cost"].keys():
			var have: int = game.inv.get(it, 0)
			parts.append("%s %d/%d" % [Cfg.ITEM_NAMES[it], have, r["cost"][it]])
		_t(", ".join(parts), Vector2(s.x / 2.0 - 320 * u, y + 56 * u), 20 * u, Color(0.8, 0.9, 0.7))


func _draw_hud(s: Vector2) -> void:
	# мини-карта
	var mm := Rect2(14 * u, 14 * u, 150 * u, 150 * u)
	if game.world != null and game.world.minimap != null:
		draw_texture_rect(game.world.minimap, mm, false)
		draw_rect(mm, Color(0, 0, 0, 0.8), false, 2 * u)
		var pp: Vector3 = game.player.global_position
		var mp := mm.position + Vector2(pp.x / Cfg.WX, pp.z / Cfg.WZ) * mm.size
		draw_circle(mp, 5 * u, Color(1, 0.1, 0.1))
		draw_circle(mp, 2.5 * u, Color.WHITE)
		_t(game.world.biome_name(int(pp.x), int(pp.z)), Vector2(mm.position.x, mm.end.y + 24 * u), 22 * u, Color(1, 1, 0.8))
	# ресурсы
	var y := 14 * u + 150 * u + 54 * u
	if game.sandbox:
		_t("Песочница: ресурсы бесконечные", Vector2(14 * u, y), 18 * u, Color(0.8, 1, 0.8))
	else:
		for it in Cfg.RESOURCE_ITEMS:
			var n: int = game.inv.get(it, 0)
			if n > 0:
				_t("%s: %d" % [Cfg.ITEM_NAMES[it], n], Vector2(14 * u, y), 20 * u)
				y += 24 * u
	# прицел
	var c := s / 2.0
	draw_line(c - Vector2(9, 0) * u, c + Vector2(9, 0) * u, Color(1, 1, 1, 0.8), 2 * u)
	draw_line(c - Vector2(0, 9) * u, c + Vector2(0, 9) * u, Color(1, 1, 1, 0.8), 2 * u)
	# кнопки
	if screen == "game":
		for b in _game_buttons():
			_draw_circle_btn(b, held.get(b["name"], false))
		if joy_touch != -1:
			draw_circle(joy_origin, 90 * u, Color(1, 1, 1, 0.12))
			draw_arc(joy_origin, 90 * u, 0, TAU, 40, Color(1, 1, 1, 0.5), 3 * u)
			draw_circle(joy_pos, 34 * u, Color(1, 1, 1, 0.45))
	# хотбар
	for i in 6:
		var rc := _slot_rect(i)
		var id: String = game.hotbar[i]
		draw_rect(rc, Color(0, 0, 0, 0.55))
		var sel: bool = (i == game.sel)
		draw_rect(rc, Color(1, 0.9, 0.3) if sel else Color(1, 1, 1, 0.4), false, (4.0 if sel else 2.0) * u)
		if id != "":
			draw_rect(Rect2(rc.position + Vector2(18, 8) * u, Vector2(30, 26) * u), _item_color(id))
			_t(Cfg.ITEM_NAMES[id], Vector2(rc.position.x, rc.end.y - 8 * u), 12 * u, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, rc.size.x)
	if game.current_item() == "ak":
		var rl := ""
		if game.player.reload_left > 0.0:
			rl = "  перезарядка..."
		_t("%d / ∞%s" % [game.player.ak_ammo, rl], Vector2(0, s.y - 100 * u), 26 * u, Color(1, 0.9, 0.5), HORIZONTAL_ALIGNMENT_CENTER, s.x)
	if hint != "":
		_t(hint, Vector2(0, s.y - 128 * u), 22 * u, Color(0.9, 1, 0.8), HORIZONTAL_ALIGNMENT_CENTER, s.x)
	var ny := s.y * 0.22
	for n in notes:
		_t(n[0], Vector2(0, ny), 26 * u, Color(1, 1, 0.7, clampf(n[1], 0.0, 1.0)), HORIZONTAL_ALIGNMENT_CENTER, s.x)
		ny += 30 * u


func _item_color(id: String) -> Color:
	match id:
		"rock": return Color(0.6, 0.6, 0.62)
		"torch": return Color(1.0, 0.6, 0.15)
		"plan": return Color(0.3, 0.5, 0.9)
		"hammer": return Color(0.65, 0.42, 0.2)
		"ak": return Color(0.25, 0.25, 0.28)
	return Color.WHITE


func _draw_radial(s: Vector2) -> void:
	draw_rect(Rect2(Vector2.ZERO, s), Color(0, 0, 0, 0.45))
	var c := s / 2.0
	var n := Cfg.BUILD_MENU.size()
	var r_in := 70.0 * u
	var r_out := 220.0 * u
	for i in n:
		var a0 := -PI / 2.0 + (float(i) - 0.5) * TAU / n + 0.02
		var a1 := -PI / 2.0 + (float(i) + 0.5) * TAU / n - 0.02
		var pts := PackedVector2Array()
		for k in range(0, 13):
			var a := lerpf(a0, a1, k / 12.0)
			pts.append(c + Vector2(cos(a), sin(a)) * r_out)
		for k in range(12, -1, -1):
			var a := lerpf(a0, a1, k / 12.0)
			pts.append(c + Vector2(cos(a), sin(a)) * r_in)
		var piece: String = Cfg.BUILD_MENU[i]
		var col := Color(0.15, 0.2, 0.15, 0.92)
		if piece == build_piece:
			col = Color(0.35, 0.55, 0.2, 0.95)
		draw_colored_polygon(pts, col)
		var am := (a0 + a1) / 2.0
		var lp := c + Vector2(cos(am), sin(am)) * (r_in + r_out) / 2.0
		_t(Cfg.PIECE_NAMES[piece], Vector2(lp.x - 80 * u, lp.y - 4 * u), 22 * u, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 160 * u)
		var cost := Cfg.piece_cost(piece, "twig" if piece != "door" else "wood")
		_t("%d дер." % cost, Vector2(lp.x - 80 * u, lp.y + 20 * u), 16 * u, Color(0.9, 1, 0.7), HORIZONTAL_ALIGNMENT_CENTER, 160 * u)
	draw_circle(c, r_in - 6 * u, Color(0, 0, 0, 0.6))
	_t("Строить", Vector2(c.x - 60 * u, c.y + 8 * u), 20 * u, Color.WHITE, HORIZONTAL_ALIGNMENT_CENTER, 120 * u)
