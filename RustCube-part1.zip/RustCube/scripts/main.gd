extends Node3D
# Точка входа: меню -> генерация мира -> игра. Режимы: survival и sandbox.

var ui: GameUI
var world: VoxelWorld
var player: Player
var builder: Builder
var sandbox := false
var inv := {}
var hotbar := ["", "", "", "", "", ""]
var sel := 0


func _ready() -> void:
	randomize()
	_setup_environment()
	var layer := CanvasLayer.new()
	add_child(layer)
	ui = GameUI.new()
	ui.game = self
	layer.add_child(ui)
	ui.start_requested.connect(_on_start)
	ui.craft_requested.connect(_on_craft)
	ui.quit_requested.connect(_on_quit)
	ui.fly_toggled.connect(_on_fly)


func _setup_environment() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var psm := ProceduralSkyMaterial.new()
	psm.sky_top_color = Color(0.35, 0.58, 0.92)
	psm.sky_horizon_color = Color(0.72, 0.85, 0.95)
	psm.ground_horizon_color = Color(0.72, 0.85, 0.95)
	psm.ground_bottom_color = Color(0.45, 0.55, 0.45)
	sky.sky_material = psm
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_SKY
	env.ambient_light_energy = 0.9
	env.fog_enabled = true
	env.fog_light_color = Color(0.75, 0.86, 0.95)
	env.fog_density = 0.004
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, 35, 0)
	sun.light_energy = 1.0
	sun.shadow_enabled = false
	add_child(sun)


func _cleanup() -> void:
	for n in [player, builder, world]:
		if n != null and is_instance_valid(n):
			n.queue_free()
	player = null
	builder = null
	world = null


func _on_start(mode: String, seed_val: int) -> void:
	sandbox = (mode == "sandbox")
	inv = {}
	sel = 0
	if sandbox:
		for r in Cfg.RESOURCE_ITEMS:
			inv[r] = 9999
		hotbar = ["rock", "torch", "plan", "hammer", "ak", ""]
	else:
		hotbar = ["rock", "torch", "", "", "", ""]
	_cleanup()
	ui.screen = "loading"
	world = VoxelWorld.new()
	add_child(world)
	world.gen_progress.connect(ui.on_progress)
	await world.generate(seed_val)
	builder = Builder.new()
	builder.world = world
	add_child(builder)
	player = Player.new()
	add_child(player)
	player.setup(self, ui, world, builder)
	player.position = world.find_spawn()
	player.equip(hotbar[sel])
	ui.screen = "game"
	if sandbox:
		notify("Песочница: всё бесконечное. Пауза -> Полёт")
	else:
		notify("Бей деревья камнем. Крафт: киянка и план")


func _on_quit() -> void:
	_cleanup()
	ui.screen = "main"


func _on_fly() -> void:
	if player != null:
		player.fly = not player.fly


func current_item() -> String:
	return hotbar[sel]


func select_slot(i: int) -> void:
	sel = clampi(i, 0, 5)
	if player != null:
		player.equip(hotbar[sel])


func has_item(item: String, n: int) -> bool:
	if sandbox:
		return true
	return inv.get(item, 0) >= n


func spend(item: String, n: int) -> void:
	if sandbox:
		return
	inv[item] = inv.get(item, 0) - n


func add_item(item: String, n: int) -> void:
	if n <= 0:
		return
	if not sandbox:
		inv[item] = inv.get(item, 0) + n
	notify("+%d %s" % [n, Cfg.ITEM_NAMES.get(item, item)])


func notify(text: String) -> void:
	ui.notify(text)


func _on_craft(key: String) -> void:
	if not Cfg.RECIPES.has(key):
		return
	if hotbar.has(key):
		notify("Уже есть: " + Cfg.RECIPES[key]["name"])
		return
	var cost: Dictionary = Cfg.RECIPES[key]["cost"]
	for it in cost.keys():
		if not has_item(it, cost[it]):
			notify("Не хватает: " + Cfg.ITEM_NAMES[it])
			return
	var slot := hotbar.find("")
	if slot == -1:
		notify("Нет места в хотбаре")
		return
	for it in cost.keys():
		spend(it, cost[it])
	hotbar[slot] = key
	notify("Создано: " + Cfg.RECIPES[key]["name"])
	ui.screen = "game"
