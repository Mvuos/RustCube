class_name AK47Model
extends RefCounted
# Первая модель: АК из кубов (смотрит вперёд по -Z). Собирается кодом, без внешних файлов.

static func _m(c: Color, rough: float = 0.8, metal: float = 0.0) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = rough
	m.metallic = metal
	return m


static func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func _cyl(parent: Node3D, radius: float, length: float, pos: Vector3, mat: Material) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = radius
	cm.bottom_radius = radius
	cm.height = length
	cm.radial_segments = 6
	mi.mesh = cm
	mi.position = pos
	mi.rotation_degrees = Vector3(90, 0, 0)
	mi.material_override = mat
	parent.add_child(mi)
	return mi


# Возвращает корневой узел. Узел "Muzzle" - точка вспышки.
static func build() -> Node3D:
	var root := Node3D.new()
	root.name = "AK47"
	var steel := _m(Color(0.13, 0.13, 0.15), 0.5, 0.6)
	var steel2 := _m(Color(0.20, 0.20, 0.22), 0.5, 0.5)
	var wood := _m(Color(0.52, 0.28, 0.10), 0.9)
	var wood_d := _m(Color(0.40, 0.21, 0.07), 0.9)
	var mag := _m(Color(0.30, 0.17, 0.09), 0.7)

	# ствольная коробка и крышка
	_box(root, Vector3(0.06, 0.085, 0.34), Vector3(0, 0, 0.0), steel)
	_box(root, Vector3(0.055, 0.022, 0.27), Vector3(0, 0.052, -0.01), steel2)
	# ствол, газовая трубка, дульный тормоз
	_cyl(root, 0.013, 0.36, Vector3(0, 0.018, -0.35), steel)
	_cyl(root, 0.009, 0.22, Vector3(0, 0.050, -0.30), steel2)
	_cyl(root, 0.017, 0.05, Vector3(0, 0.018, -0.54), steel2)
	# мушка и основание
	_box(root, Vector3(0.012, 0.04, 0.012), Vector3(0, 0.060, -0.50), steel)
	_box(root, Vector3(0.03, 0.02, 0.03), Vector3(0, 0.035, -0.50), steel)
	# прицельная планка
	_box(root, Vector3(0.03, 0.02, 0.05), Vector3(0, 0.072, -0.12), steel)
	# цевьё (дерево): нижняя и верхняя накладки
	_box(root, Vector3(0.068, 0.05, 0.20), Vector3(0, -0.012, -0.27), wood)
	_box(root, Vector3(0.062, 0.03, 0.13), Vector3(0, 0.040, -0.34), wood_d)
	# приклад
	_box(root, Vector3(0.05, 0.095, 0.25), Vector3(0, -0.012, 0.29), wood, Vector3(-6, 0, 0))
	_box(root, Vector3(0.052, 0.11, 0.025), Vector3(0, -0.02, 0.42), steel2, Vector3(-6, 0, 0))
	# пистолетная рукоять
	_box(root, Vector3(0.04, 0.10, 0.05), Vector3(0, -0.095, 0.09), wood_d, Vector3(18, 0, 0))
	# спусковая скоба
	_box(root, Vector3(0.012, 0.012, 0.07), Vector3(0, -0.058, 0.03), steel)
	# магазин: два изогнутых сегмента
	_box(root, Vector3(0.036, 0.12, 0.06), Vector3(0, -0.10, -0.075), mag, Vector3(12, 0, 0))
	_box(root, Vector3(0.036, 0.11, 0.06), Vector3(0, -0.205, -0.045), mag, Vector3(28, 0, 0))
	# рукоятка затвора
	_box(root, Vector3(0.02, 0.02, 0.03), Vector3(0.04, 0.02, -0.04), steel2)

	# вспышка выстрела
	var muzzle := Node3D.new()
	muzzle.name = "Muzzle"
	muzzle.position = Vector3(0, 0.018, -0.58)
	root.add_child(muzzle)
	var fm := StandardMaterial3D.new()
	fm.albedo_color = Color(1.0, 0.85, 0.3)
	fm.emission_enabled = true
	fm.emission = Color(1.0, 0.7, 0.2)
	fm.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	var flash := _box(muzzle, Vector3(0.07, 0.07, 0.07), Vector3.ZERO, fm, Vector3(0, 0, 45))
	flash.name = "Flash"
	flash.visible = false
	return root
