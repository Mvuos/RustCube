class_name ViewModels
extends RefCounted
# Модели предметов в руках (кубические, строятся кодом).

static func _m(c: Color, emissive: bool = false) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = c
	m.roughness = 0.9
	if emissive:
		m.emission_enabled = true
		m.emission = c
		m.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	return m


static func _box(parent: Node3D, size: Vector3, pos: Vector3, mat: Material, rot_deg: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var mi := MeshInstance3D.new()
	var bm := BoxMesh.new()
	bm.size = size
	mi.mesh = bm
	mi.position = pos
	mi.rotation_degrees = rot_deg
	mi.material_override = mat
	parent.add_child(mi)
	return mi


static func rock() -> Node3D:
	var r := Node3D.new()
	var g := _m(Color(0.55, 0.55, 0.57))
	var g2 := _m(Color(0.42, 0.42, 0.45))
	_box(r, Vector3(0.14, 0.11, 0.16), Vector3(0, 0, 0), g, Vector3(10, 25, 5))
	_box(r, Vector3(0.09, 0.08, 0.10), Vector3(0.05, 0.05, -0.03), g2, Vector3(-8, 40, 0))
	_box(r, Vector3(0.07, 0.06, 0.08), Vector3(-0.05, -0.02, 0.04), g2, Vector3(0, -20, 12))
	return r


static func torch() -> Node3D:
	var r := Node3D.new()
	_box(r, Vector3(0.05, 0.38, 0.05), Vector3(0, 0, 0), _m(Color(0.45, 0.28, 0.12)))
	_box(r, Vector3(0.07, 0.07, 0.07), Vector3(0, 0.22, 0), _m(Color(1.0, 0.55, 0.1), true), Vector3(0, 45, 0))
	_box(r, Vector3(0.04, 0.05, 0.04), Vector3(0, 0.28, 0), _m(Color(1.0, 0.85, 0.3), true), Vector3(0, 20, 0))
	var l := OmniLight3D.new()
	l.name = "Light"
	l.position = Vector3(0, 0.3, 0)
	l.light_color = Color(1.0, 0.65, 0.3)
	l.light_energy = 1.6
	l.omni_range = 12.0
	r.add_child(l)
	return r


static func hammer() -> Node3D:
	var r := Node3D.new()
	_box(r, Vector3(0.045, 0.34, 0.045), Vector3(0, 0, 0), _m(Color(0.50, 0.32, 0.14)))
	_box(r, Vector3(0.10, 0.10, 0.18), Vector3(0, 0.19, 0), _m(Color(0.60, 0.40, 0.18)))
	_box(r, Vector3(0.105, 0.105, 0.03), Vector3(0, 0.19, 0.085), _m(Color(0.35, 0.35, 0.38)))
	_box(r, Vector3(0.105, 0.105, 0.03), Vector3(0, 0.19, -0.085), _m(Color(0.35, 0.35, 0.38)))
	return r


static func plan() -> Node3D:
	var r := Node3D.new()
	_box(r, Vector3(0.30, 0.02, 0.21), Vector3(0, 0, 0), _m(Color(0.25, 0.45, 0.80)))
	_box(r, Vector3(0.24, 0.022, 0.015), Vector3(0, 0.001, -0.04), _m(Color(0.9, 0.95, 1.0)))
	_box(r, Vector3(0.24, 0.022, 0.015), Vector3(0, 0.001, 0.0), _m(Color(0.9, 0.95, 1.0)))
	_box(r, Vector3(0.24, 0.022, 0.015), Vector3(0, 0.001, 0.04), _m(Color(0.9, 0.95, 1.0)))
	return r
