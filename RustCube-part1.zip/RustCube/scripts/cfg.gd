class_name Cfg
extends RefCounted
# Все настройки игры в одном месте. Цифры можно менять.

# --- Размер мира (в блоках) ---
const WX := 192
const WZ := 192
const WY := 48
const CHUNK := 16
const BASE_H := 14
const WINTER_R := 34.0   # зима чуть больше лета
const SUMMER_R := 29.0

# --- Блоки ---
const AIR := 0
const GRASS := 1
const DIRT := 2
const STONE := 3
const SAND := 4
const SNOW := 5
const LOG_BIRCH := 6
const LOG_OAK := 7
const LOG_PALM := 8
const LOG_SPRUCE := 9
const LEAF_BIRCH := 10
const LEAF_OAK := 11
const LEAF_PALM := 12
const LEAF_SPRUCE := 13
const ORE_STONE := 14
const ORE_SULFUR := 15
const ORE_METAL := 16

# Сколько дерева даёт одно дерево целиком
const TREE_WOOD = {6: 80, 7: 120, 8: 100, 9: 80}
# За сколько ударов камнем выбивается весь ресурс
const HITS_PER_OBJECT := 8

# --- Строительство ---
const TIERS = ["twig", "wood", "stone", "metal", "mvk"]
const TIER_NAMES = {"twig": "Солома", "wood": "Дерево", "stone": "Камень", "metal": "Металл", "mvk": "МВК"}
const TIER_ITEM = {"twig": "wood", "wood": "wood", "stone": "stone", "metal": "frag", "mvk": "mvk"}
# Цена СТЕНКИ по уровням (солома 7, дерево 13 — как ты сказал)
const WALL_COST = {"twig": 7, "wood": 13, "stone": 25, "metal": 20, "mvk": 10}
# Остальные детали = цена стенки * множитель
const PIECE_FACTOR = {"foundation": 1.5, "wall": 1.0, "doorway": 1.0, "floor": 1.0}
const DOOR_COST := 20   # деревянная одинарная дверь, дерево

const PIECE_NAMES = {"foundation": "Фундамент", "wall": "Стена", "doorway": "Проём", "floor": "Перекрытие", "door": "Дверь"}
const BUILD_MENU = ["foundation", "wall", "doorway", "floor", "door"]

# --- Предметы ---
const ITEM_NAMES = {
	"rock": "Камень", "torch": "Факел", "plan": "Строит. план", "hammer": "Киянка", "ak": "АК",
	"wood": "Дерево", "stone": "Камень", "sulfur": "Сера", "metal_ore": "Металл-руда",
	"mvk_ore": "МВК-руда", "frag": "Фрагменты", "mvk": "МВК"
}
const RESOURCE_ITEMS = ["wood", "stone", "sulfur", "metal_ore", "mvk_ore", "frag", "mvk"]

# Крафт руками (верстака пока нет)
const RECIPES = {
	"hammer": {"name": "Киянка", "cost": {"wood": 30, "stone": 15}},
	"plan": {"name": "Строительный план", "cost": {"wood": 10}},
}


static func piece_cost(ptype: String, tier: String) -> int:
	if ptype == "door":
		return DOOR_COST
	return int(ceil(WALL_COST[tier] * PIECE_FACTOR[ptype]))


static func piece_item(ptype: String, tier: String) -> String:
	if ptype == "door":
		return "wood"
	return TIER_ITEM[tier]


static func tier_color(tier: String) -> Color:
	match tier:
		"twig": return Color(0.80, 0.70, 0.36)
		"wood": return Color(0.55, 0.36, 0.18)
		"stone": return Color(0.55, 0.55, 0.57)
		"metal": return Color(0.62, 0.66, 0.72)
		"mvk": return Color(0.22, 0.26, 0.34)
	return Color.WHITE


static func block_color(id: int) -> Color:
	match id:
		1: return Color(0.36, 0.66, 0.24)
		2: return Color(0.46, 0.31, 0.18)
		3: return Color(0.50, 0.50, 0.52)
		4: return Color(0.93, 0.85, 0.55)
		5: return Color(0.94, 0.97, 1.00)
		6: return Color(0.86, 0.85, 0.80)   # берёза
		7: return Color(0.40, 0.27, 0.14)   # дуб
		8: return Color(0.62, 0.48, 0.28)   # пальма
		9: return Color(0.30, 0.20, 0.12)   # ель
		10: return Color(0.52, 0.76, 0.28)
		11: return Color(0.18, 0.50, 0.16)
		12: return Color(0.22, 0.68, 0.30)
		13: return Color(0.10, 0.36, 0.24)
		14: return Color(0.62, 0.62, 0.64)
		15: return Color(0.86, 0.80, 0.30)  # серный камень, желтоватый
		16: return Color(0.58, 0.40, 0.30)  # металл-руда
	return Color.MAGENTA
